import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { User } from '../../Models/Public/UserModel';
import { UserService } from '../../Services/public-api.service';
import { Response } from '@angular/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  message: string;
  userObj: User;
  constructor(private myApiService: UserService, private route: Router) { }
  RegistrationForm = new FormGroup({
    Username: new FormControl(''),
    Password: new FormControl(''),
    Name: new FormControl(''),
    EmailID: new FormControl(''),
    PhoneNo: new FormControl('')

  });

  ngOnInit() {
  }

  onSubmit() {
    this.userObj = Object.assign({}, this.RegistrationForm.value);
    this.myApiService.saveUserRegistrationData(this.userObj).subscribe(
      data => {
        console.log("POST Request is successful ", data)
        this.message = "Successfully registred";
        alert("Successfully registred")
        this.route.navigate(["Studentlogin"]);

      },
      error => {
        console.log("Error", error);
        this.message = "Registration Failed";
      }
    );
  }
}
