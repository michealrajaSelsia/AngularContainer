
--Exec ValidateAdminLogin @Username='Raja', @Password='Raja'
Create procedure ValidateAdminLogin(@Username nvarchar(50), @Password nvarchar(50))
As
Begin
	IF exists( SELECT * FROM Admin WHERE Username = @Username AND Password = @Password)
	Begin
		Select 'True';
	End
	Else
	Begin
		Select 'False';
	End
End

