
USE [University]
GO
/****** Object:  StoredProcedure [dbo].[UpdateApplication]    Script Date: 11/11/2018 3:36:00 AM ******/
/*
Declare  @a as  TypeUserRegistration;
insert into @a values ('Userid1','hf Raja', 'Username','EmailID', 'PhoneNo', GETDATE(), 1)
exec [UpdateUser] @UserRegistration=@a
*/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Alter Procedure [dbo].[GetUserDetails]
AS 
Begin
	--Insert into UserRegistration(Userid,Name, Username,EmailID, PhoneNo, Createdon, isActive) select * from @UserRegistration;	


End

