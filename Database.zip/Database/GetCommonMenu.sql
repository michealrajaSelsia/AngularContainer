Create procedure GetCommonMenu
As
Begin
	SELECT * FROM CommonMenu
End