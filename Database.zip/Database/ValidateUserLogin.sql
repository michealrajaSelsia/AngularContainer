
GO
/****** Object:  StoredProcedure [dbo].[ValidateAdminLogin]    Script Date: 11/11/2018 4:59:00 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure ValidateUserLogin(@Username nvarchar(50), @Password nvarchar(50))
As
Begin
	IF exists( SELECT * FROM [dbo].[UserRegistration] WHERE Username = @Username AND Password = @Password)
	Begin
		Select 'True' as Result;
	End
	Else
	Begin
		Select 'False' as Result;
	End
End

alter table userregistration add Password nvarchar(50)