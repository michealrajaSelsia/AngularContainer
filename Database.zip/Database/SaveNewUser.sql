
/****** Object:  StoredProcedure [dbo].[UpdateApplication]    Script Date: 11/11/2018 3:36:00 AM ******/
/*
Declare  @a as  TypeUserRegistration;
insert into @a values ('Userid1','hf Raja', 'Username','EmailID', 'PhoneNo', GETDATE(), 1)
exec [UpdateUser] @UserRegistration=@a
*/

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create Procedure [dbo].[UpdateUser](@UserRegistration TypeUserRegistration readonly)
AS 
Begin
	--Insert into UserRegistration(Userid,Name, Username,EmailID, PhoneNo, Createdon, isActive) select * from @UserRegistration;	

	insert into UserRegistration(Userid,Name, Username,EmailID, PhoneNo, Createdon, isActive)
	select a.Userid, a.Name, a.Username,a.EmailID, a.PhoneNo, a.Createdon, a.isActive from @UserRegistration as a left join UserRegistration as b on a.Userid= b.Userid where b.Userid is null

	update a set 
 a.Name=b.Name, a.Username=b.Username,
	a.EmailID=b.EmailID, a.PhoneNo=a.PhoneNo, a.Createdon=b.Createdon, a.isActive=b.isActive
	 from  UserRegistration as a inner join @UserRegistration as b on a.Userid =b.Userid;

End

