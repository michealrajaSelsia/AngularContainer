Create procedure GetAdminMenu
As
Begin
	SELECT * FROM AdminMenu
End