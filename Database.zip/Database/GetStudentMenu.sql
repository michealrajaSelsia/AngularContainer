Create procedure GetStudentMenu
As
Begin
	SELECT * FROM StudentMenu
End