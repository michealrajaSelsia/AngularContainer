Create procedure GetApplicationStatus
As
Begin
 select * from ApplicationStatus
End
