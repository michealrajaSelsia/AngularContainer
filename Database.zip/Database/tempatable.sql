Declare @ad as TypeApplication 
select * into #temptbl from  Application where id=1
alter table #temptbl drop column id 
select * from #temptbl
insert into @ad select * from  #temptbl
select * from @ad

select * from Application as l
 left join #temptbl as r on l.ApplicationID=r.ApplicationID 
 where r.ApplicationID is Null

 drop table #temptbl




Insert into Application(
ApplicationID	,	
Course 			,
Fname 			,
Lname 			,
Fullname 		,
DOB 			,
Gender			,
FatherName 		,
MotherName		,
Religion 		,
Nationality 	,
Email 			,
MobileNo		,
P_Address 		,
C_Address 		,
--Photo 			,
SSLCSchoolName	,
SSLCMark 		,
SSLCPercentage	,
HSCSchoolName 	,
HSCMark 		,
HSCPercentage 	,
UGSchoolName 	,
UGMark 			,
UGPercentage 	,
PGSchoolName 	,
PGMark 			,
PGPercentage 	,
CreateOn 		,
isActive)

select
l.ApplicationID		,
l.Course 		  ,
l.Fname 		  ,
l.Lname 		  ,
l.Fullname 		  ,
l.DOB 			  ,
l.Gender		  ,
l.FatherName 	  ,
l.MotherName	  ,
l.Religion 		  ,
l.Nationality 	  ,
l.Email 		  ,
l.MobileNo		  ,
l.P_Address 	  ,
l.C_Address 	  ,
--l.Photo 		  ,
l.SSLCSchoolName  ,
l.SSLCMark 		  ,
l.SSLCPercentage  ,
l.HSCSchoolName   ,
l.HSCMark 		  ,
l.HSCPercentage   ,
l.UGSchoolName 	  ,
l.UGMark 		  ,
l.UGPercentage 	  ,
l.PGSchoolName 	  ,
l.PGMark 		  ,
l.PGPercentage 	  ,
l.CreateOn 		  ,
l.isActive 		


from Application as l
 left outer join @Application1 as r on l.ApplicationID=r.ApplicationID 
 where r.ApplicationID is Null



































Exec UpdateApplication @Application1= @ad


select * from Application