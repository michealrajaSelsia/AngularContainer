Create procedure GetReligion
As
Begin
	SELECT * FROM Religion
End
