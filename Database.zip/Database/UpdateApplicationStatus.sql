--Create type TypeApplicationStatus as table (ApplicationID nvarchar(10), ApprovedStatus nvarchar(50), ApprovedBy nvarchar(50), ApplicationComment nvarchar(200),ApprovedOn date)
--declare @a as TypeApplicationStatus
--insert into @a values('APP1000','Completed', 'Raja','Good',GETDATE())
--exec UpdateApplicationStatus @ApplicationStatus =@a

Create procedure UpdateApplicationStatus(@ApplicationStatus as TypeApplicationStatus Readonly)
As
Begin
 insert into ApplicationStatus(ApplicationID , ApprovedStatus, ApprovedBy, ApplicationComment,ApprovedOn) select * from  @ApplicationStatus
End

