
Create procedure GetCourses
As
Begin
	SELECT * FROM Courses
End