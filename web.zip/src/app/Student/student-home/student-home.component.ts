import { Component, OnInit } from '@angular/core';
import {GalleryImage} from '../../Models/Public/GalleryImageModel'
import {UserService} from '../../Services/public-api.service';
@Component({
  selector: 'app-student-home',
  templateUrl: './student-home.component.html',
  styleUrls: ['./student-home.component.css']
})
export class StudentHomeComponent implements OnInit {
  public gallary: GalleryImage[];
  constructor(private myser :UserService ) { }

  ngOnInit() {
  }

  public getDataFromServer1() {
    this.myser.getGalleryImages1().subscribe((gallaries)=>this.gallary = gallaries)  
  }
}
