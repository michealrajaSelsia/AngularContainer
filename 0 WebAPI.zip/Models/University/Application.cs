﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceProvider.Models
{
    public class Application
    {
        public string ApplicationID { get; set; }
        public string Course { get; set; }
        public string Columns { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Fullname { get; set; }
        public DateTime DOB { get; set; }
        public Boolean Gender { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string Religion { get; set; }
        public string Nationality { get; set; }
        public string Email { get; set; }
        public Int64 MobileNo { get; set; }
        public string P_Address { get; set; }
        public string C_Address { get; set; }
        //public string Photo { get; set; }
        public string SSLCSchoolName { get; set; }
        public Int64 SSLCMark { get; set; }
        public Int64 SSLCPercentage { get; set; }
        public string HSCSchoolName { get; set; }
        public Int64 HSCMark { get; set; }
        public Int64 HSCPercentage { get; set; }
        public string UGSchoolName { get; set; }
        public Int64 UGMark { get; set; }
        public Int64 UGPercentage { get; set; }
        public string PGSchoolName { get; set; }
        public Int64 PGMark { get; set; }
        public Int64 PGPercentage { get; set; }
        public DateTime CreateOn { get; set; }
        public Boolean isActive { get; set; }
    }
}