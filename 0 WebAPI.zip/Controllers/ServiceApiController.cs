﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ServiceProvider.Models.Common;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http.Cors;

namespace ServiceProvider.Controllers
{
    public class ServiceApiController : ApiController
    {


        // GET: api/ServiceApi
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/ServiceApi/5
        public string Get(int id)
        {
            return "value";
        }
        //http://localhost:49728/api/ServiceApi/addEmployee?empid=IS4541&name=Priya&department=BSC&phoneNo=82202122&empAddress=cuddalore
        [HttpGet]
        public IHttpActionResult addEmployee(string empid, string name, string department, string phoneNo, string empAddress)
        {
            try
            {
                SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();
                sqlString.DataSource = "DESKTOP-F231U8O\\MICHEALKING";
                sqlString.InitialCatalog = "employee";
                sqlString.IntegratedSecurity = true;
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("addEmp", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@empid", empid);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@department", department);
                        cmd.Parameters.AddWithValue("@phoneNo", Convert.ToInt64(phoneNo));
                        cmd.Parameters.AddWithValue("@empAddress", empAddress);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json("Success");
        }

        [HttpGet]
        public IHttpActionResult getEmployee()
        {
            SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();
            sqlString.DataSource = "DESKTOP-F231U8O\\MICHEALKING";
            sqlString.InitialCatalog = "employee";
            sqlString.IntegratedSecurity = true;
            SqlDataReader r;
            List<Employee> empCollection = new List<Employee>();
            try
            {
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("getEmp", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@empid", "");
                        cmd.Parameters.AddWithValue("@name", "");
                        cmd.Parameters.AddWithValue("@phoneNo", "");
                        con.Open();
                        r = cmd.ExecuteReader();
                        while (r.Read())
                        {
                            empCollection.Add(new Employee { empid = r["empid"].ToString(), name = r["name"].ToString(), department = r["department"].ToString(), phoneNo = r["phoneNo"].ToString(), empAddress = r["empAddress"].ToString() });
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json(empCollection);
        }

        [HttpGet]
        public IHttpActionResult updateEmployee(string empid, string name, string department, string phoneNo, string empAddress)
        {
            try
            {
                SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();

                sqlString.DataSource = @"localhost\sqlexpress";
                sqlString.InitialCatalog = "employee";
                sqlString.IntegratedSecurity = true;

                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("addEmp", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@empid", empid);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@department", department);
                        cmd.Parameters.AddWithValue("@phoneNo", Convert.ToInt64(phoneNo));
                        cmd.Parameters.AddWithValue("@empAddress", empAddress);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json("Success");
        }


        [HttpGet]
        public IHttpActionResult validateUser(string username, string password)
        {
            SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();
            sqlString.DataSource = "DESKTOP-F231U8O\\MICHEALKING";
            sqlString.InitialCatalog = "employee";
            sqlString.IntegratedSecurity = true;
            SqlDataReader r;
            bool isValidUser = false;
            try
            {
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("validateUser", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserName", username);
                        cmd.Parameters.AddWithValue("@Password", password);
                        con.Open();
                        r = cmd.ExecuteReader();
                        while (r.Read())
                        {
                            isValidUser = Convert.ToBoolean(r["Result"].ToString());
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json(isValidUser);
        }


        [HttpGet]
        public IHttpActionResult addUser(string UID, string UName , string Pas, string Name, string Email, string PNo)
        {
            SqlConnectionStringBuilder sqlString = new SqlConnectionStringBuilder();
            sqlString.DataSource = "DESKTOP-F231U8O\\MICHEALKING";
            sqlString.InitialCatalog = "employee";
            sqlString.IntegratedSecurity = true;
            SqlDataReader r;
            bool isValidUser = false;
            try
            {
                using (SqlConnection con = new SqlConnection(sqlString.ToString()))
                {
                    using (SqlCommand cmd = new SqlCommand("addUser", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@UserID", UID);
                        cmd.Parameters.AddWithValue("@UserName", UName);
                        cmd.Parameters.AddWithValue("@Password", Pas);
                        cmd.Parameters.AddWithValue("@Name", Name);
                        cmd.Parameters.AddWithValue("@Email", Email);
                        cmd.Parameters.AddWithValue("@PhoneNo", PNo);
                        con.Open();
                        r = cmd.ExecuteReader();
                        while (r.Read())
                        {
                            isValidUser = Convert.ToBoolean(r["Result"].ToString());
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                return Json("Failed" + ex.Message.ToString());
            }
            finally
            {

            }
            return Json(isValidUser);
        }
        // POST: api/ServiceApi
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/ServiceApi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/ServiceApi/5
        public void Delete(int id)
        {
        }


    }
}
