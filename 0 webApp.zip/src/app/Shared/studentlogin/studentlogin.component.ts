import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, FormControlName} from '@angular/forms'
import { Router} from '@angular/router';
import { Http} from '@angular/http';
import { UserService} from '../../Services/public-api.service';
import {StudentLoginM} from '../../Models/Public/StudentLoginModel';
import { Response } from '@angular/http';
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'app-studentlogin',
  templateUrl: './studentlogin.component.html',
  styleUrls: ['./studentlogin.component.css']
})
export class StudentloginComponent implements OnInit {
  errorMsg:string;
  objAdModel:StudentLoginM;
  StudentLogin=new FormGroup({
    Username:new FormControl(''),
    Password:new FormControl('')
  });
  constructor( private route:Router, private http:Http, private myApiService:UserService) { }
  ngOnInit() {
   
  }

  ValidateLogin() {

    this.objAdModel= Object.assign({},this.StudentLogin.value);
    this.myApiService.validatestudent(this.objAdModel).subscribe(
      (data:any) => {
        if(data)
         {
           localStorage.setItem("StudentUserName",data.userName);
           localStorage.setItem("StudentToken",data.access_token);
           localStorage.setItem("userName",data.userName);
           localStorage.setItem("Claims",data.Claims);
           localStorage.setItem("Id",data.Id);
           localStorage.setItem("PhoneNumber",data.PhoneNumber);
          
           this.route.navigate(["StudentHome"])
          
         }
         else
         {
          this.errorMsg='Enter valid username and password.'
         }
      },
      error => {
        console.log("Error", error);
        this.errorMsg='Enter valid username and password.'
      }
    )
  }
 }

