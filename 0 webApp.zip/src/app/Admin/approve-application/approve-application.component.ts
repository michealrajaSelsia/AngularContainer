import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approve-application',
  templateUrl: './approve-application.component.html',
  styleUrls: ['./approve-application.component.css']
})
export class ApproveApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
