import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators, FormGroup, FormControlName } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';
import { MaterialAppModule } from '../../MainConfig/ngmaterial.module';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { UserService } from '../../Services/public-api.service';
import { AdminLoginM } from '../../Models/Public/AdminLoginModel';
import { Response } from '@angular/http';
import {ApplicationModel} from '../../Models/Public/Application';
import { Course } from 'src/app/Models/Public/Courses';
import { Religion } from 'src/app/Models/Public/Religion';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-editapplication',
  templateUrl: './editapplication.component.html',
  styleUrls: ['./editapplication.component.css']
})
export class EditapplicationComponent implements OnInit {
  imageUrl:string='/assets/Images/default_avatar_male.jpg';
  fileToUpload:File=null;
  courseCollection:Course[];
  religionCollection:Religion[];
  applicationID:string;
  filedata:any;   
  objApplicationModel:ApplicationModel
  errorMsg:string;
  ApplicationForm = new FormGroup({
    ApplicationID: new FormControl(this.applicationID),
    Course: new FormControl(''),
    Fname: new FormControl(''),
    Lname: new FormControl(''),
    Fullname: new FormControl(''),
    DOB: new FormControl(''),
    Gender: new FormControl(''),
    FatherName: new FormControl(''),
    MotherName: new FormControl(''),
    Religion: new FormControl(''),
    Nationality: new FormControl(''),
    Email: new FormControl(''),
    MobileNo: new FormControl(''),
    P_Address: new FormControl(''),
    C_Address: new FormControl(''),
   // Photo: new FormControl(''),
    SSLCSchoolName: new FormControl(''),
    SSLCMark: new FormControl(''),
    SSLCPercentage: new FormControl(''),
    HSCSchoolName: new FormControl(''),
    HSCMark: new FormControl(''),
    HSCPercentage: new FormControl(''),
    UGSchoolName: new FormControl(''),
    UGMark: new FormControl(''),
    UGPercentage: new FormControl(''),
    PGSchoolName: new FormControl(''),
    PGMark: new FormControl(''),
    PGPercentage: new FormControl(''),
    CreateOn: new FormControl(''),
    isActive: new FormControl(''),
  });
  constructor(private http: Http, private route: Router, private myApiService:UserService) { }

   
  ngOnInit() {    
    this. getDataCourse();    
    this. getDataReligion(); 
    //this. GetApplicationID(); 
    this.getFoods();
  }


  getFoods() {
      this.http.get('http://localhost:49728/api/Common/GetApplicationID').pipe(map(data => {
        console.log('RSAD'+data);
      })).subscribe(result => {
        console.log('RSAD'+result);
        
      });

  }
  public getDataCourse() {
    this.myApiService.getGalleryCourses().subscribe((courses)=>this.courseCollection = courses)
  }
  public getDataReligion() {
    this.myApiService.getGalleryReligion().subscribe((religion)=>this.religionCollection = religion)
  }
  public GetApplicationID() {
    this.myApiService.GetApplicationID().subscribe(
      applicationID=>{
        this.applicationID = applicationID.toString()
      })
    console.log(this.applicationID)
  }

handleFileInput(file:FileList){
  this.fileToUpload=file.item(0);
  var reader=new FileReader();
  
  reader.onload=(event:any)=>{
    this.imageUrl=event.target.result;
  }
  reader.readAsDataURL(this.fileToUpload);
}

  ClearFeild()
  {
    alert("Cleared");
  }

  onApplicationSubmit() {
    this.objApplicationModel= Object.assign({},this.ApplicationForm.value);
    console.warn("Result"+this.objApplicationModel);
    this.objApplicationModel.Gender= (this.objApplicationModel.Gender==false)?false:true;
    this.objApplicationModel.MobileNo= (this.objApplicationModel.MobileNo==0)? 0:this.objApplicationModel.MobileNo;
    
    this.myApiService.saveApplication(this.objApplicationModel,this.fileToUpload ).subscribe(
      data => {
        if(data)
         {
          alert("Success");
         }
         else
         {
          alert("Failed");
         }
      },
      error => {
        console.log("Error", error);
      }
    )
  }

}
