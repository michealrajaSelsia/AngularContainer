import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payfees',
  templateUrl: './payfees.component.html',
  styleUrls: ['./payfees.component.css']
})
export class PayfeesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
