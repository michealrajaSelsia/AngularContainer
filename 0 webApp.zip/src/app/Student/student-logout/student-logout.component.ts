import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-logout',
  templateUrl: './student-logout.component.html',
  styleUrls: ['./student-logout.component.css']
})
export class StudentLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
