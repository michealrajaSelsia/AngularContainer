export class Religion{
    ID:number;
    ReligionName:string;
    isActive:number;
}
